package com.pleng.spike.finalbasestructure.Bundle;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import com.pleng.spike.finalbasestructure.R;
import com.pleng.spike.finalbasestructure.TextFile.TextFileFragment;

public class BundleUse extends Fragment {
    private Bundle bundle;
    private TextFileFragment obj;
    private FragmentManager fm;
    private FragmentTransaction ft;
    @Override
    public void onActivityCreated(@Nullable android.os.Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }
    private void passBundle(){
        bundle = new Bundle();
        bundle.putString("bundleKey", "bundleValue");

        fm = getActivity().getSupportFragmentManager();
        ft = fm.beginTransaction();
        obj = new TextFileFragment();
        obj.setArguments(bundle);

        ft.replace(R.id.main_view, obj);
        ft.commit();
    }

    private void useBundle(){
        if(getArguments() != null){
            bundle = getArguments();
            bundle.getString("bundleKey");

        }
    }
}

package com.pleng.spike.finalbasestructure.TextFile;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.pleng.spike.finalbasestructure.R;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class TextFileFragment extends Fragment {
    private TextView txtContent;
    private EditText userNameField,nameField;
    private int col = 2;
    private int count = 0;
    private String row[] = new String[col];
    protected ArrayList<String[]> arrayList = new ArrayList<>();
    StringBuilder concator = new StringBuilder();
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Button readButton = getView().findViewById(R.id.read_button_textFile_fragment);
        Button saveButton = getView().findViewById(R.id.save_button_text_file_fragment);
        userNameField = getView().findViewById(R.id.userName_textFile_fragment);
        nameField = getView().findViewById(R.id.name_textFile_fragment);
        txtContent = getView().findViewById(R.id.txtContent_textFile_fragment);
        readButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                arrayList.clear();
                //Check realtime permission if run higher API 23
                if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(getActivity(), new String[]{
                            Manifest.permission.READ_EXTERNAL_STORAGE
                    },1);
                    return;
                }

                //Read File
                ArrayList<String[]> outputData = FileHelper.ReadFile(getActivity());

                txtContent.setText("");
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Check realtime permission if run higher API 23
                if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(getActivity(), new String[]{
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                    },2);
                    return;
                }

                //Save To File
                if (FileHelper.saveToFile(
                        userNameField.getText().toString() + "," +
                        nameField.getText().toString() + ","
                )){
                    Toast.makeText(getActivity(),"Saved to file",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getActivity(),"Error save file!!!",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_text_file, container, false);
    }
}

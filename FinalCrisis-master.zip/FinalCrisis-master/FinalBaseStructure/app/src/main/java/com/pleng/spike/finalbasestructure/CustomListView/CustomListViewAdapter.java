package com.pleng.spike.finalbasestructure.CustomListView;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.pleng.spike.finalbasestructure.R;
import com.pleng.spike.finalbasestructure.User;

import java.util.ArrayList;

public class CustomListViewAdapter extends ArrayAdapter<User> {

    private Context context;
    private ArrayList<User> userArrayList = new ArrayList<>();

    public CustomListViewAdapter(@NonNull Context context, int resource, ArrayList<User> userArrayList) {
        super(context, resource, userArrayList);
        this.context = context;
        this.userArrayList = userArrayList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView,@NonNull ViewGroup parent) {
        View view = LayoutInflater.from(context).inflate(
                R.layout.custom_listview_adapter,
                parent,
                false
        );

        TextView username = view.findViewById(R.id.username_custom_listview_adapter);
        TextView firstName = view.findViewById(R.id.firstName_custom_listview_adapter);
        TextView lastName = view.findViewById(R.id.lastName_custom_listview_adapter);

        username.setText(userArrayList.get(position).getUsername());
        firstName.setText(userArrayList.get(position).getFirstName());
        lastName.setText(userArrayList.get(position).getLastName());

        return view;
    }
}

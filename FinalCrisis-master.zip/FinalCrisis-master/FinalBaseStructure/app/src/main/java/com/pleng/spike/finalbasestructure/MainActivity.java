package com.pleng.spike.finalbasestructure;

import android.Manifest;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.pleng.spike.finalbasestructure.CustomListView.CustomListViewFragment;
import com.pleng.spike.finalbasestructure.SharedPreferences.SharedPreferencesFragment;
import com.pleng.spike.finalbasestructure.TextFile.TextFileFragment;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if(savedInstanceState == null){
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.main_view, new SharedPreferencesFragment())
                    .commit();
        }


    }
}

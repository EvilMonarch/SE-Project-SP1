package com.pleng.spike.finalbasestructure.CustomListView;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.pleng.spike.finalbasestructure.R;
import com.pleng.spike.finalbasestructure.User;

import java.util.ArrayList;

public class CustomListViewFragment extends Fragment {
    private ArrayList<User> userArrayList = new ArrayList<>();
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        //Add Data to Array List
        User user1 = new User();
        user1.setUsername("admin");
        user1.setFirstName("Pongpanot");
        user1.setLastName("Na Ubon");

        User user2 = new User();
        user2.setUsername("lib");
        user2.setFirstName("God");
        user2.setLastName("Libary");

        userArrayList.add(user1);
        userArrayList.add(user2);

        ListView listView = getView().findViewById(R.id.listview_custom_listview_fragment);
        CustomListViewAdapter adapter = new CustomListViewAdapter(
                getContext(),
                R.layout.custom_listview_adapter,
                userArrayList

        );
        listView.setAdapter(adapter);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_custom_listview, container, false);
    }
}
